# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_mainQgtDNI.ui'
##
## Created by: Qt User Interface Compiler version 6.1.3
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import *  # type: ignore
from PySide6.QtGui import *  # type: ignore
from PySide6.QtWidgets import *  # type: ignore

import images.img

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1180, 733)
        self.verticalLayout = QVBoxLayout(Form)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.frame = QFrame(Form)
        self.frame.setObjectName(u"frame")
        self.frame.setStyleSheet(u"border-image: url(:/bg/bg/Dak1.jpg);")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.frame)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.frame_2 = QFrame(self.frame)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setMinimumSize(QSize(0, 50))
        self.frame_2.setMaximumSize(QSize(16777215, 50))
        self.frame_2.setStyleSheet(u"border-image: none;\n"
"background-color: rgba(255, 255, 255, 25);")
        self.frame_2.setFrameShape(QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Raised)

        self.verticalLayout_2.addWidget(self.frame_2)

        self.mainLayout = QFrame(self.frame)
        self.mainLayout.setObjectName(u"mainLayout")
        self.mainLayout.setStyleSheet(u"border-image: none;")
        self.mainLayout.setFrameShape(QFrame.StyledPanel)
        self.mainLayout.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.mainLayout)
        self.gridLayout.setSpacing(20)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, -1, 0, -1)
        self.frame_3 = QFrame(self.mainLayout)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setStyleSheet(u"background-color: rgba(0, 0, 0, 112);\n"
"")
        self.frame_3.setFrameShape(QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.frame_3)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.donutLay = QHBoxLayout()
        self.donutLay.setObjectName(u"donutLay")

        self.horizontalLayout_2.addLayout(self.donutLay)


        self.gridLayout.addWidget(self.frame_3, 0, 1, 2, 1)

        self.frame_6 = QFrame(self.mainLayout)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setMaximumSize(QSize(16777215, 120))
        self.frame_6.setStyleSheet(u"background-color: rgba(0, 0, 0, 112)")
        self.frame_6.setFrameShape(QFrame.StyledPanel)
        self.frame_6.setFrameShadow(QFrame.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.frame_6)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.output = QLabel(self.frame_6)
        self.output.setObjectName(u"output")
        self.output.setStyleSheet(u"QLabel{\n"
"	background:none;\n"
"	color: rgb(255, 255, 255);\n"
"	font: 36pt \"Microsoft YaHei UI\";\n"
"}")
        self.output.setAlignment(Qt.AlignCenter)
        self.output.setWordWrap(True)

        self.verticalLayout_3.addWidget(self.output)

        self.label = QLabel(self.frame_6)
        self.label.setObjectName(u"label")
        self.label.setStyleSheet(u"QLabel{\n"
"	background:none;\n"
"	color: rgb(255, 255, 255);\n"
"	\n"
"	font: 290 12pt \"Microsoft YaHei UI Light\";\n"
"}")
        self.label.setAlignment(Qt.AlignCenter)

        self.verticalLayout_3.addWidget(self.label)


        self.gridLayout.addWidget(self.frame_6, 2, 1, 1, 1)

        self.widgetContainer = QFrame(self.mainLayout)
        self.widgetContainer.setObjectName(u"widgetContainer")
        self.widgetContainer.setMinimumSize(QSize(220, 0))
        self.widgetContainer.setMaximumSize(QSize(220, 16777215))
        self.widgetContainer.setStyleSheet(u"background-color: rgba(255, 255, 255, 25);")
        self.widgetContainer.setFrameShape(QFrame.StyledPanel)
        self.widgetContainer.setFrameShadow(QFrame.Raised)
        self.gridLayout_2 = QGridLayout(self.widgetContainer)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.gridLayout_3 = QGridLayout()
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.gridLayout_3.setHorizontalSpacing(10)
        self.gridLayout_3.setVerticalSpacing(25)
        self.kompri = QLineEdit(self.widgetContainer)
        self.kompri.setObjectName(u"kompri")
        self.kompri.setStyleSheet(u"QLineEdit{\n"
"	background:rgba(0, 0, 0, 55);\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"	border:none;\n"
"}")

        self.gridLayout_3.addWidget(self.kompri, 4, 1, 1, 1)

        self.tiefeLbl = QLabel(self.widgetContainer)
        self.tiefeLbl.setObjectName(u"tiefeLbl")
        self.tiefeLbl.setStyleSheet(u"QLabel{\n"
"	background:none;\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"}")

        self.gridLayout_3.addWidget(self.tiefeLbl, 3, 0, 1, 1)

        self.aufloesung = QLineEdit(self.widgetContainer)
        self.aufloesung.setObjectName(u"aufloesung")
        self.aufloesung.setStyleSheet(u"QLineEdit{\n"
"	background:rgba(0, 0, 0, 55);\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"	border:none;\n"
"}")

        self.gridLayout_3.addWidget(self.aufloesung, 5, 1, 1, 1)

        self.breiteLbl = QLabel(self.widgetContainer)
        self.breiteLbl.setObjectName(u"breiteLbl")
        self.breiteLbl.setStyleSheet(u"QLabel{\n"
"	background:none;\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"}")

        self.gridLayout_3.addWidget(self.breiteLbl, 1, 0, 1, 1)

        self.spieldauerLbl = QLabel(self.widgetContainer)
        self.spieldauerLbl.setObjectName(u"spieldauerLbl")
        self.spieldauerLbl.setStyleSheet(u"QLabel{\n"
"	background:none;\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"}")

        self.gridLayout_3.addWidget(self.spieldauerLbl, 6, 0, 1, 1)

        self.spieldauer = QLineEdit(self.widgetContainer)
        self.spieldauer.setObjectName(u"spieldauer")
        self.spieldauer.setStyleSheet(u"QLineEdit{\n"
"	background:rgba(0, 0, 0, 55);\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"	border:none;\n"
"}")

        self.gridLayout_3.addWidget(self.spieldauer, 6, 1, 1, 1)

        self.aufloesungLbl = QLabel(self.widgetContainer)
        self.aufloesungLbl.setObjectName(u"aufloesungLbl")
        self.aufloesungLbl.setStyleSheet(u"QLabel{\n"
"	background:none;\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"}")

        self.gridLayout_3.addWidget(self.aufloesungLbl, 5, 0, 1, 1)

        self.comboBox = QComboBox(self.widgetContainer)
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setStyleSheet(u"QComboBox{\n"
"	background:rgba(0, 0, 0, 55);\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"	border:none;\n"
"}\n"
"\n"
"QListView{\n"
"	color: rgb(255, 255, 255);\n"
"}")

        self.gridLayout_3.addWidget(self.comboBox, 0, 1, 1, 1)

        self.hoehe = QLineEdit(self.widgetContainer)
        self.hoehe.setObjectName(u"hoehe")
        self.hoehe.setStyleSheet(u"QLineEdit{\n"
"	background:rgba(0, 0, 0, 55);\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"	border:none;\n"
"}")

        self.gridLayout_3.addWidget(self.hoehe, 2, 1, 1, 1)

        self.tiefe = QLineEdit(self.widgetContainer)
        self.tiefe.setObjectName(u"tiefe")
        self.tiefe.setStyleSheet(u"QLineEdit{\n"
"	background:rgba(0, 0, 0, 55);\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"	border:none;\n"
"}")

        self.gridLayout_3.addWidget(self.tiefe, 3, 1, 1, 1)

        self.comboBox_2 = QComboBox(self.widgetContainer)
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.setObjectName(u"comboBox_2")
        self.comboBox_2.setStyleSheet(u"QComboBox{\n"
"	background:rgba(0, 0, 0, 55);\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"	border:none;\n"
"}\n"
"\n"
"QListView{\n"
"	color: rgb(255, 255, 255);\n"
"}")

        self.gridLayout_3.addWidget(self.comboBox_2, 7, 1, 1, 1)

        self.label_5 = QLabel(self.widgetContainer)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setStyleSheet(u"QLabel{\n"
"	background:none;\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"}")

        self.gridLayout_3.addWidget(self.label_5, 0, 0, 1, 1)

        self.breite = QLineEdit(self.widgetContainer)
        self.breite.setObjectName(u"breite")
        self.breite.setStyleSheet(u"QLineEdit{\n"
"	background:rgba(0, 0, 0, 55);\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"	border:none;\n"
"}")

        self.gridLayout_3.addWidget(self.breite, 1, 1, 1, 1)

        self.kompriLbl = QLabel(self.widgetContainer)
        self.kompriLbl.setObjectName(u"kompriLbl")
        self.kompriLbl.setMinimumSize(QSize(110, 0))
        self.kompriLbl.setStyleSheet(u"QLabel{\n"
"	background:none;\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"}")

        self.gridLayout_3.addWidget(self.kompriLbl, 4, 0, 1, 1)

        self.hoeheLbl = QLabel(self.widgetContainer)
        self.hoeheLbl.setObjectName(u"hoeheLbl")
        self.hoeheLbl.setStyleSheet(u"QLabel{\n"
"	background:none;\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"}")

        self.gridLayout_3.addWidget(self.hoeheLbl, 2, 0, 1, 1)

        self.label_6 = QLabel(self.widgetContainer)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setStyleSheet(u"QLabel{\n"
"	background:none;\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"}")

        self.gridLayout_3.addWidget(self.label_6, 7, 0, 1, 1)

        self.calcBtn = QPushButton(self.widgetContainer)
        self.calcBtn.setObjectName(u"calcBtn")
        self.calcBtn.setMinimumSize(QSize(0, 30))
        self.calcBtn.setMaximumSize(QSize(16777215, 30))
        self.calcBtn.setStyleSheet(u"QPushButton{\n"
"	background:rgba(0, 0, 0, 55);\n"
"	color: rgb(255, 255, 255);\n"
"	font: 10pt \"Microsoft YaHei UI\";\n"
"	border:1px solid  rgb(255, 255, 255);\n"
"	border-radius:10px;\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"	background:rgba(0, 0, 0, 0);\n"
"}\n"
"QPushButton:pressed{\n"
"background:rgba(0, 0, 0, 200);\n"
"}")

        self.gridLayout_3.addWidget(self.calcBtn, 8, 0, 1, 2)


        self.gridLayout_2.addLayout(self.gridLayout_3, 0, 0, 1, 1)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.gridLayout_2.addItem(self.verticalSpacer, 3, 0, 1, 1)


        self.gridLayout.addWidget(self.widgetContainer, 0, 0, 3, 1)


        self.verticalLayout_2.addWidget(self.mainLayout)

        self.frame_4 = QFrame(self.frame)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setMinimumSize(QSize(0, 50))
        self.frame_4.setMaximumSize(QSize(16777215, 50))
        self.frame_4.setStyleSheet(u"border-image: none;\n"
"background-color: rgba(255, 255, 255, 25);")
        self.frame_4.setFrameShape(QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Raised)

        self.verticalLayout_2.addWidget(self.frame_4)


        self.verticalLayout.addWidget(self.frame)

        QWidget.setTabOrder(self.comboBox, self.breite)
        QWidget.setTabOrder(self.breite, self.hoehe)
        QWidget.setTabOrder(self.hoehe, self.tiefe)
        QWidget.setTabOrder(self.tiefe, self.kompri)
        QWidget.setTabOrder(self.kompri, self.aufloesung)
        QWidget.setTabOrder(self.aufloesung, self.spieldauer)
        QWidget.setTabOrder(self.spieldauer, self.comboBox_2)
        QWidget.setTabOrder(self.comboBox_2, self.calcBtn)

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.output.setText("")
        self.label.setText("")
        self.tiefeLbl.setText(QCoreApplication.translate("Form", u"Farbtiefe", None))
        self.breiteLbl.setText(QCoreApplication.translate("Form", u"Breite", None))
        self.spieldauerLbl.setText(QCoreApplication.translate("Form", u"Spieldauer", None))
        self.aufloesungLbl.setText(QCoreApplication.translate("Form", u"Aufl\u00f6sung", None))
        self.comboBox.setItemText(0, QCoreApplication.translate("Form", u"Bilddatei", None))
        self.comboBox.setItemText(1, QCoreApplication.translate("Form", u"Papierscan", None))
        self.comboBox.setItemText(2, QCoreApplication.translate("Form", u"Sounddatei", None))
        self.comboBox.setItemText(3, QCoreApplication.translate("Form", u"Videodatei", None))

        self.comboBox_2.setItemText(0, QCoreApplication.translate("Form", u"KiB", None))
        self.comboBox_2.setItemText(1, QCoreApplication.translate("Form", u"MiB", None))
        self.comboBox_2.setItemText(2, QCoreApplication.translate("Form", u"GiB", None))
        self.comboBox_2.setItemText(3, QCoreApplication.translate("Form", u"KB", None))
        self.comboBox_2.setItemText(4, QCoreApplication.translate("Form", u"MB", None))
        self.comboBox_2.setItemText(5, QCoreApplication.translate("Form", u"GB", None))

        self.label_5.setText(QCoreApplication.translate("Form", u"Dateityp", None))
        self.kompriLbl.setText(QCoreApplication.translate("Form", u"Komprimieung", None))
        self.hoeheLbl.setText(QCoreApplication.translate("Form", u"H\u00f6he", None))
        self.label_6.setText(QCoreApplication.translate("Form", u"Gr\u00f6\u00dfe", None))
        self.calcBtn.setText(QCoreApplication.translate("Form", u"Berechnen", None))
    # retranslateUi

