import json
import psutil
import random
import functools
from PySide6.QtCharts import *

hdd = psutil.disk_usage("/")
print(hdd.total / (1000 ))

from ui_main import *

### JSON DATEI IMPORT
with open("jsonFile\lists.json", "r", encoding="utf-8") as file:
    data = json.load(file)


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

#=> IMPORT UI
        self.ui = Ui_Form()
        self.ui.setupUi(self)

#=> LABEL UND LINE_EDIT HIDE
        self.ui.aufloesung.hide()
        self.ui.aufloesungLbl.hide()
        self.ui.spieldauer.hide()
        self.ui.spieldauerLbl.hide()

#=> CALC KLASSE IMPORT
        self.calculator = Calculator(self)

#=> CALC BUTTON
        self.ui.calcBtn.clicked.connect(self.calculator.calc)
        self.setShow(self.ui.calcBtn, "white")

#=> COMBO_BOX
        self.ui.comboBox.currentTextChanged.connect(self.calculator.comboChoice)

#=>
        self.space = [(2 ** 10), (2 ** 20), (2 ** 30), (1000), (1000 ** 2), (1000 ** 3)]

#=> CHART
        self.series = QPieSeries()
        self.slice = QPieSlice()
        self.chart = QChart()
        self.chart.setBackgroundVisible(False)
        self.chartview = QChartView(self.chart)
        self.ui.donutLay.addWidget(self.chartview)

#=> DONUT CHART ANZEIGEN
    def showDonut(self, x):
        self.m_donuts = []

        self.series = QPieSeries()
        self.slice = QPieSlice()

    #=> GESAMT: FESTPLATTE
        self.slice =self.series.append(f"Festplatte gesamt: {hdd.total / self.space[x]:.2f} {self.calculator.bLst[x]}", hdd.total / self.space[x])
        self.slice.setLabelColor(Qt.white)
        self.slice.setLabelVisible(True)
        self.slice.setLabelPosition(QPieSlice.LabelOutside)

    #=> Verfügbarer Speicherplatz
        self.slice = self.series.append( f"Verfügbarer Speicherplatz: {hdd.free / self.space[x]:.2f} {self.calculator.bLst[x]}", hdd.free / self.space[x])
        self.slice.setLabelColor(Qt.white)
        self.slice.setLabelVisible(True)
        self.slice.setLabelPosition(QPieSlice.LabelOutside)

    #=> BELEGTER SPEICHERPLATZ
        self.slice = self.series.append( f"In Benutzung: {hdd.used / self.space[x]:.2f} {self.calculator.bLst[x]}", hdd.used / self.space[x])
        self.slice.setLabelColor(Qt.white)
        self.slice.setLabelVisible(True)
        self.slice.setLabelPosition(QPieSlice.LabelOutside)

    #=> GRÖSSE DES DONUTS
        self.series.setHoleSize(0.35)
        self.series.setPieSize(0.6)
        self.m_donuts.append(self.series)

        self.chart = QChart()
        self.chart.addSeries(self.series)
        self.chart.setBackgroundVisible(False)

    #=> ANIMATIONS-OPTIONEN
        self.chart.setAnimationOptions(QChart.SeriesAnimations)
        self.chart.setAnimationEasingCurve(QEasingCurve.OutBounce)

        self.chart.setTitleBrush(Qt.white)
        self.chart.setTitleFont(QFont("Eraser", 20))
        self.chart.legend().setLabelColor(Qt.white)

        self.chartview = QChartView(self.chart)
        self.chartview.setRenderHint(QPainter.Antialiasing)

        self.setShow(self.chart, "white")
        self.ui.donutLay.addWidget(self.chartview)

    #=> TIMER FUER DIE ROTATION
        self.updateTimer = QTimer(self)
        self.updateTimer.timeout.connect(self.updateRotation)
        self.updateTimer.start(3250)

#=> ROTATION DES DONUTS
    def updateRotation(self):
        for donut in self.m_donuts:
            phaseShift = random.randrange(-50, 100)
            donut.setPieStartAngle(donut.pieStartAngle() + phaseShift)
            donut.setPieEndAngle(donut.pieEndAngle() + phaseShift)

#=> DONUT SCHLIESSEN
    def clearDonut(self):
        self.chartview.close()

# => SCHATTEN:
    def setShow(self, widget, color):
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(20)
        shadow.setXOffset(0)
        shadow.setYOffset(0)
        shadow.setColor(color)
        widget.setGraphicsEffect(shadow)


class Calculator:
    def __init__(self, parent):
        
        self.parent = parent

        self.switchLst = ["{0} / 8 / 1024", "{0} / 8 / 1024 / 1024", "{0} / 8 / 1024 / 1024 / 1024",
                          "{0} / 8 / 1000", "{0} / 8 / 1000 / 1000", "{0} / 8 / 1000 / 1000 / 1000"]
        self.bLst = ["KiB", "MiB", "GiB", "KB", "MB", "GB"]
        self.edits = [self.parent.ui.aufloesung, self.parent.ui.aufloesungLbl, self.parent.ui.spieldauer,
                      self.parent.ui.spieldauerLbl]

# => INHALT DER COMBO_BOX
        self.comboLst = ["Bilddatei", "Papierscan", "Sounddatei", "Videodatei"]

        self.lblLst = [self.parent.ui.breiteLbl, self.parent.ui.hoeheLbl, self.parent.ui.tiefeLbl,
                       self.parent.ui.kompriLbl, self.parent.ui.aufloesungLbl, self.parent.ui.spieldauerLbl]

        self.editLst = [self.parent.ui.breite, self.parent.ui.hoehe, self.parent.ui.tiefe,
                       self.parent.ui.kompri, self.parent.ui.aufloesung, self.parent.ui.spieldauer]

#=> BERECHNUNG DER BILDDATEI
    def calcImage(self):
        return float(self.parent.ui.breite.text()) * float(self.parent.ui.hoehe.text()) * \
               float(self.parent.ui.tiefe.text()) / float(self.parent.ui.kompri.text())

#=> PAPIERSCAN FORMAT
    def paperScan(self):
        if len(self.parent.ui.aufloesung.text()) > 0:
            breite = float(self.parent.ui.breite.text()) * float(self.parent.ui.aufloesung.text()) / 2.54
            hoehe = float(self.parent.ui.hoehe.text()) * float(self.parent.ui.aufloesung.text()) / 2.54
            return breite * hoehe * float(self.parent.ui.tiefe.text()) / float(self.parent.ui.kompri.text())

#=> AUDIO BERECHNEN
    def calcSound(self):
        if len(self.parent.ui.aufloesung.text()) > 0:
            laenge = float(self.parent.ui.breite.text()) * 60
            return laenge * float(self.parent.ui.hoehe.text()) * float(self.parent.ui.tiefe.text()) * \
                   float(self.parent.ui.kompri.text()) / float(self.parent.ui.aufloesung.text())

#=> VIDEODATEI BERECHNEN
    def calcVideo(self):
        if len(self.parent.ui.aufloesung.text()) > 0 and len(self.parent.ui.spieldauer.text()) > 0:
            laenge = float(self.parent.ui.spieldauer.text()) * 60
            return laenge * float(self.parent.ui.aufloesung.text()) * float(self.parent.ui.breite.text()) * \
                   float(self.parent.ui.hoehe.text()) * float(self.parent.ui.tiefe.text()) / float(self.parent.ui.kompri.text())

#=> RÜCKGABE-WERTE UMRECHNEN + DONUT-CHART EIGENSCHAFTEN
    def switch(self, x):
        cmdLst = [self.calcImage(), self.paperScan(), self.calcSound(), self.calcVideo()]
        for i, val in enumerate(self.bLst):
            if self.parent.ui.comboBox_2.currentText() == self.bLst[i]:
                self.parent.showDonut(i)
                self.parent.chart.setTitle(self.comboLst[x])
                self.parent.ui.output.setText(str(round(eval(self.switchLst[i].format(cmdLst[x])),2))+self.bLst[i])
                self.parent.ui.label.setText(self.switchLst[i].format(data["Rechenweg"][x]))
                self.parent.slice = self.parent.series.append(str(round(eval(self.switchLst[i].format(cmdLst[x])),2))+self.bLst[i],
                                                              float(round(eval(self.switchLst[i].format(cmdLst[x])),2)))
                self.parent.slice.setExploded()
                self.parent.slice.setLabelVisible(True)
                self.parent.slice.setLabelPosition(QPieSlice.LabelOutside)
                self.parent.slice.setLabelColor("lime")

#=> ANZEIGE DER KALKULATION
    def calc(self):
        for x in range(len(self.comboLst)):
            try:
                if self.parent.ui.comboBox.currentText() == self.comboLst[x]:
                    self.parent.clearDonut()
                    self.switch(x)
            except:
                if any(self.editLst[x] is not type(float) for x in range(len(self.editLst))):
                    self.parent.ui.output.setText("Ungütlige Eingabe")

#=> COMBO_BOX AUSWAHL AENDERN
    def comboChoice(self):
        for  key in data:
            for x in range(len(self.edits)):
                for j, val in enumerate(data[key]):
                    if self.parent.ui.comboBox.currentText() == key:
                        if len(data[key]) < 5:
                            self.edits[x].hide()
                            self.lblLst[j].setText(val)
                        if len(data[key]) == 5:
                            self.edits[x%2].show()
                            self.edits[2].hide(), self.edits[3].hide()
                            self.lblLst[j].setText(val)
                        if len(data[key]) > 5:
                            self.edits[x].show()
                            self.lblLst[j].setText(val)


if __name__ == '__main__':
    import sys
    app = QApplication(sys.argv)
    mw = MainWindow()
    mw.setWindowTitle("Dateigröße-Rechner")
    mw.show()
    app.exec()